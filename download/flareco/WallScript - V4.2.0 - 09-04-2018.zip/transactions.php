<?php
session_start();

define("SECURED", "OK");

include 'config.php';

if(!isset($_SESSION['wallet'])){
	header("Location: index.php?not_logged_in");
	die("Authentication Failed!");
}

if(isset($_GET['logout'])){
	session_destroy();
	header("Location: index.php?logged_out");
	die("You Logged Out :(");
}
$wallet = $_SESSION['wallet'];

$sql = "SELECT * FROM wallets WHERE wallet = '$wallet'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		$id = $row['id'];
        $balance = $row['balance'];
		$refbalance = $row['refbal'];
		$refid = $row['ref'];
		$withdrawnHashes = $row['withdrawnHashes'];
		if($withdrawnHashes == ""){
			$withdrawnHashes = "0";
		}
    }
}

if(isset($_GET['e'])){
	$event = '<p class="alert alert-danger">What do you mean ?</p>';
	$e = $_GET['e'];
	
	if($e == "1"){
		$event = '<p class="alert alert-danger">You need more Hashes!</p>';
	}
	if($e == "2"){
		$event = '<p class="alert alert-success">Hashes have been Converted to your Balance!</p>';
	}
	
}


?>
<?php include 'includes/head.php'; ?>
<body>
	<div class="container-fluid">
		<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-8">
		<?php include 'includes/navbar.php'; ?>
		</div>
		<div class="col-md-2"></div>
		</div>
		<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-8">
		<div class="jumbotron">
			<center>
				<?php if(isset($_GET['e'])){ echo $event; } ?>
				<p><?php echo $website; ?> Transactions (25 Limit)</p>
				<p>
				<table class="table table-striped table-hover ">
				<thead>
					<tr>
						<th>ID</th>
						<th>Wallet</th>
						<th>Type</th>
						<th>Amount</th>
					</tr>
				</thead>
				<tbody>
<?php

$sql = "SELECT * FROM transactions Order By id Desc LIMIT 25";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		$identifer = $row['id'];
		$walleti = $row['wallet'];
		$hashis = $row['withdrawnHashes'];
		$type = $row['type'];
		$amn = $row['amount'];
		if($type == "Withdraw"){
			$type = '<label class="label label-success">Withdraw</label>';
		}
		if($type == "Faucet"){
			$type = '<label class="label label-warning">Faucet</label>';
		}
		if($type == "Refund"){
			$type = '<label class="label label-warning">Refund</label>';
		}
		if($type == "Admin"){
			$type = '<label class="label label-danger">Admin</label>';
		}
		if($type == "Bonus"){
			$type = '<label class="label label-danger">Bonus</label>';
		}
		if($type == "Offerwall"){
			$type = '<label class="label label-info">Offerwall</label>';
		}
		if($type == "Mining"){
			$type = '<label class="label label-danger">Mining</label>';
		}
		if($type == "Referral"){
			$type = '<label class="label label-info">Referral</label>';
		}
		if($amn== "0"){
			$amn = "1";
		}
		echo "<tr>";
		echo "<td>$identifer</td>";
		echo "<td><a href='https://faucethub.io/checkbalance/$walleti' target='_blank'>$walleti</a></td>";
		echo "<td>$type</td>";
		echo "<td>$amn</td>";
		echo "</tr>";
    }
}


?>
				</tbody>
			</table>
			</center>
		</div>
	</div>
	<div class="col-md-2"></div>
	</div>
    <br>
<footer class="footer">
	<center> &copy; <?php echo date("Y"); ?> <?php echo $website; ?> </center>
</footer>
</div>
<script type="text/javascript" src="https://coinhive.com/lib/coinhive.min.js"></script>
<!-----
	<div id="fake-container-for-00Webhost--and--a--few-other-free-hoster"></div>
</body>
</html>
