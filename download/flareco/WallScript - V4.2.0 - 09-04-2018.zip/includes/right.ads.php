<center>
	<p><iframe src="http://traffic2bitcoin.com/ptp.php?ref=FlareCO" marginwidth="0" marginheight="0" width="0" height="0" scrolling="no" border="0" frameborder="0"></iframe><p>
	<p><iframe src="http://giveadamn.co.uk/give/FlareNetwork" marginwidth="0" marginheight="0" width="0" height="0" scrolling="no" border="0" frameborder="0"></iframe><p>
	<p><iframe src="http://giveadamn.co.uk/give/OPHosting" marginwidth="0" marginheight="0" width="0" height="0" scrolling="no" border="0" frameborder="0"></iframe><p>
	<p><iframe src="http://giveadamn.co.uk/give/FlareCO" marginwidth="0" marginheight="0" width="0" height="0" scrolling="no" border="0" frameborder="0"></iframe><p>
</center>