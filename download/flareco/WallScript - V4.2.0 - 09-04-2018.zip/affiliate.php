<?php
session_start();
include 'config.php';
define("SECURED", "OK");
if(!isset($_SESSION['wallet'])){
	header("Location: index.php?not_logged_in");
	die("Authentication Failed!");
}

if(isset($_GET['logout'])){
	session_destroy();
	header("Location: index.php?logged_out");
	die("You Logged Out :(");
}
$wallet = $_SESSION['wallet'];

$sql = "SELECT * FROM wallets WHERE wallet = '$wallet'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		$id = $row['id'];
        $balance = $row['balance'];
		$refbalance = $row['refbal'];
		$refid = $row['ref'];
    }
}


?>
<?php include 'includes/head.php'; ?>
<body>
	<div class="container-fluid">
		<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-8">
		<?php include 'includes/navbar.php'; ?>
		</div>
		<div class="col-md-2"></div>
		</div>
		<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-8">
			<div class="jumbotron">
				<center>
					<p><h2>Affiliate</h2></p>
					<p><h3>Your Affiliate Link:</h3></p>
					<p><h3><font color="cyan"><?php echo $weburl; ?>?ref=<?php echo $wallet; ?></font></h3></p>
					<p>Current Refshare: <?php echo $refshare; ?>%</p>
					<p><h5>Ref Earnings are added to your Account Balance</h5></p>
				</center>
			</div>
		</div>
		<div class="col-md-2"></div>
		</div>
	</div>
    <br>
<footer class="footer">
	<center> &copy; 2017 <?php echo $website; ?> </center>
</footer>
</div>
<!-----
	<div id="fake-container-for-00Webhost"></div>
</body>
</html>
