<?php
session_start();
include 'config.php';
define("SECURED", "OK");
if(!isset($_SESSION['wallet'])){
	header("Location: $weburl/index?not_logged_in");
	die("Authentication Failed!");
}

if(isset($_GET['logout'])){
	session_destroy();
	header("Location: index.php?logged_out");
	die("You Logged Out :(");
}
$wallet = $_SESSION['wallet'];

$sql = "SELECT * FROM wallets WHERE wallet = '$wallet'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		$id = $row['id'];
        $balance = $row['balance'];
		$refbalance = $row['refbal'];
		$refid = $row['ref'];
		$lastclaim = $row['lastclaim'];
		$lastclaim = $lastclaim+$timewaiting;
    }
}

$timestamp = time();

if(isset($_POST['g-recaptcha-response'])){
	
	$resp = $_POST['g-recaptcha-response'];
	$ip = $_SERVER['REMOTE_ADDR'];
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,"https://www.google.com/recaptcha/api/siteverify");
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS,
			"secret=$recaptcha_private&response=$resp&ip=$ip");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$server_output = curl_exec ($ch);
	curl_close ($ch);
	
	$json = json_decode($server_output);
	
	if (!$json->hostname){
		header("Location: ?e=1");
		die("OK");
	} else {
		if($lastclaim <= $timestamp){
			$sql = "UPDATE wallets SET balance = balance + '$reward' WHERE id = '$id'";
			$runner = $conn->query($sql);
			
			$sql = "INSERT INTO transactions(id, wallet, type, amount)VALUES('', '$wallet', 'Faucet', '$reward')";
			$runner = $conn->query($sql);
			
			$newtime = time();
			$sql = "UPDATE wallets SET lastclaim = '$newtime' WHERE id = '$id'";
			$runner = $conn->query($sql);
			
			if($refid == "none"){
				
			} else {
				$refpay = $reward/"100";
				$refpay = $refpay*$refshare;
				$refpay = ceil($refpay);
				$sql = "UPDATE wallets SET balance = balance + '$refpay' WHERE wallet = '$refid'";
				$run = $conn->query($sql);
				$sql = "UPDATE wallets SET refbal = refbal + '$refpay' WHERE wallet = '$refid'";
				$run = $conn->query($sql);
				$sql = "INSERT INTO transactions(id, wallet, type, amount)VALUES('', '$refid', 'Referral', '$refpay')";
				$runner = $conn->query($sql);
			}
			
			if($shorturl == "true"){
				if($shorturl_service == "1"){
					$build = "$weburl/faucet?e=2&w=$reward";
					$build = rawurlencode($build);
					$build = "http://1ink.cc/api/create.php?uid=$shorturl_service_1inc_id&uname=$shorturl_service_1inc_uname&url=$build";
					$result = file_get_contents("$build");
					
					$res = "http://1ink.cc/" . $result;
					header("Location: $res");
					die();
				}
				if($shorturl_service == "2"){
					$build = "$weburl/faucet?e=2&w=$reward";
					$build = rawurlencode($build);
					$build = "http://onlinebee.in/api?api=$shorturl_service_onlinebee_apikey&url=$build&format=text";
					
					$res = file_get_contents($build);
					
					header("Location: $res");
					die();
				}
			}
			header("Location: ?e=2&w=$reward");
			die("OK");
		} else {
			$calc = $lastclaim-$timestamp;
			header("Location: ?e=3&w=$calc");
			die("OK");
		}
	}
	
}

if(isset($_GET['e'])){
	$e = $_GET['e'];
	$tin = "0";
	if(isset($_GET['w'])){
		$tin = $_GET['w'];
	}
	
	if($e == "1"){
		$event = '<p class="alert alert-danger">Invalid Captcha!</p>';
	}
	if($e == "2"){
		$event = '<p class="alert alert-success">Claimed: '.$tin.' '.$smallcurrency.'</p>';
	}
	if($e == "3"){
		$event = '<p class="alert alert-danger">You need to wait: '.$tin.' seconds!</p>';
	}
}


?>
<?php include 'includes/head.php'; ?>
<script src='https://www.google.com/recaptcha/api.js'></script>
<body>
	<div class="container-fluid">
		<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-8">
		<?php include 'includes/navbar.php'; ?>
		</div>
		<div class="col-md-2"></div>
		</div>
		<div class="row">
		<div class="col-md-2">
			<?php include 'includes/left.ads.php'; ?>
		</div>
		<div class="col-md-8">
			<div class="jumbotron">
				<center>
					<?php if($event){ echo $event; } ?>
					<p><h2>Faucet</h2></p>
					<p><h4>Claim Every <?php echo $timewaiting; ?> seconds!</h4></p>
					<p><form action="" method="POST"><div class="g-recaptcha" data-sitekey="<?php echo $recaptcha_public; ?>"></div></p>
					<p><input type="submit" name="claim" class="btn btn-success" value="Claim Now!"></form></p>
					<p><h5>Per Claim: <?php echo $reward; ?> <?php echo $smallcurrency; ?> (Can be Random on Claim!)</h5></p>
					<p>
					</p>
				</center>
			</div>
		</div>
		<div class="col-md-2">
			<?php include 'includes/right.ads.php'; ?>
		</div>
		</div>
	</div>
    <br>
<footer class="footer">
	<center> &copy; 2017 <?php echo $website; ?> </center>
</footer>
</div>
<!-----
	<div id="fake-container-for-00Webhost"></div>
</body>
</html>
