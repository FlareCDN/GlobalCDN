<?php
session_start();
include 'config.php';
define("SECURED", "OK");
if(!isset($_SESSION['wallet'])){
	header("Location: index.php?not_logged_in");
	die("Authentication Failed!");
}

if(isset($_GET['logout'])){
	session_destroy();
	header("Location: index.php?logged_out");
	die("You Logged Out :(");
}
$wallet = $_SESSION['wallet'];

$sql = "SELECT * FROM wallets WHERE wallet = '$wallet'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		$id = $row['id'];
        $balance = $row['balance'];
		$refbalance = $row['refbal'];
		$refid = $row['ref'];
    }
}


?>
<?php include 'includes/head.php'; ?>
<body>
	<div class="container-fluid">
		<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-8">
		<?php include 'includes/navbar.php'; ?>
		<?php if($multiplicator == "true"){ echo '<center><p class="alert alert-success"><i>Multiplicator Bonus Active! (x'.$multiplicator_amount.')</i></p></center>'; } ?>
		<h3>Your wallet : <?php echo $wallet; ?></h3><!------Your Ref: <?php echo $refid; ?>------->
		<h3>Total Earnings : <?php echo $balance; ?></h3>
		<h3><b id="wallname">Personaly</b></h3>
		</div>
		<div class="col-md-2"></div>
		</div>
		<div class="row">
		<div class="col-md-2">
			<?php include 'includes/left.ads.php'; ?>
		</div>
		<div class="col-md-8">
			<center>
				<p>
					<?php if($ptcwall_status == "true"){ ?><a href="" onClick="changeWall('ptcwall'); return false;"><img src="img/ptcw.jpg" width="20%"></a><?php } ?>
					<?php if($personaly_status == "true"){ ?><a href="" onClick="changeWall('personaly'); return false;"><img src="img/personaly.png" width="20%"></a><?php } ?>
					<?php if($adscendmedia_status == "true"){ ?><a href="" onClick="changeWall('adscendmedia'); return false;"><img src="img/adscendmedia.webp" width="20%"></a><?php } ?>
					<?php if($superrewards_status == "true"){ ?><a href="" onClick="changeWall('superrewards'); return false;"><img src="img/superrewards.png" width="20%"></a><?php } ?>
				</p>
			</center>
			<iframe name="iframebody" id="iframebody" src="https://persona.ly/widget/?appid=<?php echo $personaly_id; ?>&userid=<?php echo $id; ?>" width="100%" style="height: 800px; width: 100%; border: 0;"></iframe>
		</div>
		<div class="col-md-2">
			<?php include 'includes/right.ads.php'; ?>
		</div>
		</div>
		<br>
	</div>
</div>
     <br>
</div>
<?php include 'includes/footer.ads.php'; ?>
<script>

	function changeWall(wallname){
		<?php if($ptcwall_status == "true"){ ?>
		if(wallname === "ptcwall"){
			var q = document.getElementById("iframebody").src = "http://www.ptcwall.com/index.php?view=ptcwall&pubid=<?php echo $pubid; ?>&usrid=<?php echo $id; ?>";
			var z = document.getElementById("wallname").innerHTML = "PTCWall";
		}
		<?php } ?>
		<?php if($personaly_status == "true"){ ?>
		if(wallname === "personaly"){
			var q = document.getElementById("iframebody").src = "https://persona.ly/widget/?appid=<?php echo $personaly_id; ?>&userid=<?php echo $id; ?>";
			var z = document.getElementById("wallname").innerHTML = "Personaly";
		}
		<?php } ?>
		<?php if($adscendmedia_status == "true"){ ?>
		if(wallname === "adscendmedia"){
			var q = document.getElementById("iframebody").src = "https://asmwall.com/adwall/publisher/<?php echo $adscendmedia_pub_id; ?>/profile/<?php echo $adscendmedia_wall_id; ?>?subid1=<?php echo $id; ?>";
			var z = document.getElementById("wallname").innerHTML = "AdscendMedia";
		}
		<?php } ?>
		<?php if($superrewards_status == "true"){ ?>
		if(wallname === "superrewards"){
			var q = document.getElementById("iframebody").src = "https://wall.superrewards.com/super/offers?h=<?php echo $superrewards_app_hash; ?>&uid=<?php echo $id; ?>";
			var z = document.getElementById("wallname").innerHTML = "SuperRewards";
		}
		<?php } ?>
	}
</script>
<footer class="footer">
	<center> &copy; <?php echo date("Y"); ?> <?php echo $website; ?> </center>
</footer>
</div>
	<!-----
	<div id="fake-container-for-00Webhost"></div>
</body>
</html>
