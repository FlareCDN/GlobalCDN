<?php

include '../config.php';

if($adscendmedia_status == "false"){
	die("Disabled");
}

if(isset($_GET['id'])){
	if(isset($_GET['amount'])){
		if(isset($_GET['secret'])){
			
			$user = $_GET['id'];
			$amount = $_GET['amount'];
			$hash = $_GET['secret'];
			
			if($multiplicator == "true"){
				$amount = $amount*$multiplicator_amount;
			}
			
				
				$sql = "SELECT * FROM wallets WHERE id = '$user' LIMIT 1";
				$result = $conn->query($sql);
				if ($result->num_rows > 0) {
					while($row = $result->fetch_assoc()) {
						$wallet = $row['wallet'];
						$ref = $row['ref'];
					}
				} else {
					die("NOC");
				}
				
				$sql = "UPDATE wallets SET balance = balance + '$amount' WHERE wallet = '$wallet'";
				$res = $conn->query($sql);
				
				if($ref == "none"){
					$supreme = "NOC";
				} else {
					$calc = $amount/"100";
					$calc = $calc*$refshare;
					$calc = ceil($calc);
					$sql = "UPDATE wallets SET balance = balance + '$calc' WHERE wallet = '$ref'";
					$txn = $conn->query($sql);
				}
				
				
				$sql = "INSERT INTO transactions(id, wallet, type, amount)VALUES('', '$wallet', 'Offerwall', '$amount')";
				$res = $conn->query($sql);
			
		}
	}
}


?>