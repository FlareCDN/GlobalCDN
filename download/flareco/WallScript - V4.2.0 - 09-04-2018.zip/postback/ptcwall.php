<?php
include '../config.php';


$sent_pw = $_REQUEST['pwd'];
$credited = trim($_REQUEST['r']);
$id = trim($_REQUEST['usr']);

if($multiplicator == "true"){
	$credited = $credited*$multiplicator_amount;
}


$calc = $credited / 100;
$calc = $calc * $refshare;
$calc = floor($calc);

if($ptcwall_status == "false"){
	die("Disabled");
}

if($sent_pw == $postpass){
	
	$sql = "SELECT * FROM wallets WHERE id = '$id'";
	$result = $conn->query($sql);
	$checko = "0";
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$wallet = $row['wallet'];
			$ref = $row['ref'];
			$checko = '1';
		}
	}
	
	if($checko == "1"){
		$sql = "UPDATE wallets SET balance = balance + '$credited' WHERE wallet = '$wallet'";
		$res = $conn->query($sql);
		$sql = "INSERT INTO transactions(id, wallet, type, amount)VALUES('', '$wallet', 'Offerwall', '$credited')";
		$runner = $conn->query($sql);
	}
	
	if($ref == "none"){
		die("ok");
	} else {
		$sql = "UPDATE wallets SET balance = balance + '$calc' WHERE wallet = '$ref'";
		$res = $conn->query($sql);
		$sql = "UPDATE wallets SET refbal = refbal + '$calc' WHERE wallet = '$ref'";
		$res = $conn->query($sql);
		$sql = "INSERT INTO transactions(id, wallet, type, amount)VALUES('', '$ref', 'Referral', '$calc')";
		$runner = $conn->query($sql);
	}
	
	die("ok");
} else {
	die("ok");
}
?>