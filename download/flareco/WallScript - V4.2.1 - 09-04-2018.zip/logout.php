<?php

include 'config.php';

session_destroy();

header("Location: $weburl?logged_out");
die("USELESS_LIFE");
?>