<?php

include '../config.php';


$sig = md5($_REQUEST['id'].':'.$_REQUEST['new'].':'.$_REQUEST['uid'].':'.$superrewards_postback_key);

$getID = $_REQUEST['id'];
$getNEW = $_REQUEST['new'];
$getUID = $_REQUEST['uid'];

$total = $_REQUEST['total'];

if($multiplicator == "true"){
	$total = $total*$multiplicator_amount;
}

if($sig == $_REQUEST['sig']){
	
	$sql = "SELECT * FROM wallets WHERE id = '$getUID' LIMIT 1";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$wallet = $row['wallet'];
			$ref = $row['ref'];
		}
	} else {
		die("1");
	}
	
	$sql = "UPDATE wallets SET balance = balance + '$total' WHERE wallet = '$wallet'";
	$res = $conn->query($sql);
	
	$sql = "INSERT INTO transactions(id, wallet, type, amount)VALUES('', '$wallet', 'Offerwall', '$total')";
	$res = $conn->query($sql);
	
	if($ref == "none"){
		
	} else {
		$calc = $total/100;
		$calc = $calc*$refshare;
		$calc = ceil($calc);
		
		$sql = "UPDATE wallets SET balance = balance + '$calc' WHERE wallet = '$ref'";
		$res = $conn->query($sql);
	
		$sql = "INSERT INTO transactions(id, wallet, type, amount)VALUES('', '$ref', 'Referral', '$calc')";
		$res = $conn->query($sql);
		
	}
	
	die("1");
	
} else {
	die("1");
}

?>