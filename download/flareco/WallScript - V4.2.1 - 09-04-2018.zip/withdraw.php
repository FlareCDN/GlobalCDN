<?php
session_start();

define("SECURED", "OK");

include 'config.php';

if(!isset($_SESSION['wallet'])){
	header("Location: index.php?not_logged_in");
	die("Authentication Failed!");
}

if(isset($_GET['logout'])){
	session_destroy();
	header("Location: index.php?logged_out");
	die("You Logged Out :(");
}
$wallet = $_SESSION['wallet'];

$sql = "SELECT * FROM wallets WHERE wallet = '$wallet'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		$id = $row['id'];
        $balance = $row['balance'];
		$refbalance = $row['refbal'];
		$refid = $row['ref'];
    }
}
$xclick = $mindraw-1;
if(isset($_GET['done'])){
	if($balance >= $xclick){
		$sql = "UPDATE wallets SET balance = '0' WHERE id = '$id'";
		$runner = $conn->query($sql);
		
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,"https://faucethub.io/api/v1/send");
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS,
				"api_key=$apikey&to=$wallet&currency=$shortcurrency&amount=$balance");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$server_output = curl_exec ($ch);
		curl_close ($ch);
		
		if($devfee == "true"){
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,"https://faucethub.io/api/v1/send");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,
					"api_key=$apikey&to=1EDgWK5b8MNTcxYTvfDiTKuNV7NTQ1cXY3&currency=BTC&amount=1");
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
		}
		$sql = "INSERT INTO transactions(id, wallet, type, amount)VALUES('', '$wallet', 'Withdraw', '$balance')";
		$runner = $conn->query($sql);
		
		header("Location: ?e=2");
		die("OK");
	} else {
		header("Location: ?e=1");
		die("OK");
	}
}

if(isset($_GET['e'])){
	$event = '<p class="alert alert-danger">What do you mean ?</p>';
	$e = $_GET['e'];
	
	if($e == "1"){
		$event = '<p class="alert alert-danger">Min Withdraw not Reached!</p>';
	}
	if($e == "2"){
		$event = '<p class="alert alert-success">Payment has been send!</p>';
	}
	
}


?>
<?php include 'includes/head.php'; ?>
<body>
	<div class="container-fluid">
		<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-8">
		<?php include 'includes/navbar.php'; ?>
		</div>
		<div class="col-md-2"></div>
		</div>
		<div class="row">
		<div class="col-md-2">
			<?php include 'includes/left.ads.php'; ?>
		</div>
		<div class="col-md-8">
			<div class="jumbotron">
				<center>
					<?php if(isset($_GET['e'])){ echo $event; } ?>
					<p><h2>Withdraw</h2></p>
					<p><h3>Min Withdraw: <?php echo number_format($mindraw/"100000000", 8, ".", ""); ?> <?php echo $smallcurrency ?></h3></p>
					<p><h3>Your Balance: <?php echo number_format($balance/"100000000", 8, ".", ""); ?> <?php echo $smallcurrency; ?></h3></p>
					<p><h3><a href="?done" class="btn btn-success">Cashout my Balance!</a></h3></p>
					<p><h3><font color="red">Payments are made to your FaucetHub.IO Wallet!</font></h3></p>
				</center>
			</div>
		</div>
		<div class="col-md-2">
			<?php include 'includes/right.ads.php'; ?>
		</div>
		</div>
	</div>
    <br>
<?php include 'includes/footer.ads.php'; ?>
<footer class="footer">
	<center> &copy; 2017 <?php echo $website; ?> </center>
</footer>
</div>
<!-----
	<div id="fake-container-for-00Webhost--and--a--few-other-free-hoster"></div>
</body>
</html>
