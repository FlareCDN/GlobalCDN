<?php
session_start();
include 'config.php';
define("SECURED", "OK");
if(!isset($_SESSION['wallet'])){
	header("Location: index.php?not_logged_in");
	die("Authentication Failed!");
}

if(isset($_GET['logout'])){
	session_destroy();
	header("Location: index.php?logged_out");
	die("You Logged Out :(");
}
$wallet = $_SESSION['wallet'];

$sql = "SELECT * FROM wallets WHERE wallet = '$wallet'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		$id = $row['id'];
        $balance = $row['balance'];
		$refbalance = $row['refbal'];
		$refid = $row['ref'];
    }
}

$myAPI = file_get_contents("https://api.coinhive.com/user/balance?secret=$coinhive_private&name=$wallet");

$myAPI = json_decode($myAPI);

if($myAPI->name){
	$minedHashes = $myAPI->balance;
} else {
	$minedHashes = "0";
}

?>
<?php include 'includes/head.php'; ?>
<body>
	<div class="container-fluid">
		<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-8">
		<?php include 'includes/navbar.php'; ?>
		</div>
		<div class="col-md-2"></div>
		</div>
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="jumbotron">
					<p><h3>Your Wallet</p>
					<p><h4><a href="https://faucethub.io/balance/<?php echo $wallet; ?>" target="_blank"><?php echo $wallet; ?></a></h4></p>
					<p><h3>Total Earnings</h3></p>
					<p><h4><?php echo $balance; ?></h4></p>
					<p><h3>Ref Earnings</h3></p>
					<p><h4><?php echo $refbalance; ?></h4></p>
					<p><h3>Hashes</h3></p>
					<p><h4 id="ah"><?php echo $minedHashes; ?></h4></p>
					<br>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>
</div>
     <br>
</div>
<footer class="footer">
	<center> &copy; 2017 <?php echo $website; ?> </center>
</footer>
</div>
	<!-----
	<div id="fake-container-for-00Webhost"></div>
</body>
</html>
