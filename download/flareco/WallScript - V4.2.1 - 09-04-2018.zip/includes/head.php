<?php

if(!defined("SECURED")){
	die("No Direct Access allowed!");
}


?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="https://www.ophosting.net">
    <link rel="icon" href="">
    <title><?php echo $website; ?> - Earn <?php echo $currency; ?> just by clicking.</title>
	<!---Bootstrap---->
	<link href="//cdn.flareco.net/bootswatch/superhero/bootstrap.css" rel="stylesheet">
	<!-----Other Stuff------>
    <link href="css/jumbotron-narrow.css" rel="stylesheet">
</head>