<div class="header clearfix">
			<nav>
				<ul class="nav nav-pills pull-left">
					<li role="presentation" class="active"><a href="<?php echo $weburl; ?>dashboard">Dashboard</a></li>
					<li role="presentation"><a href="<?php echo $weburl; ?>earn">Earn</a></li>
					<li role="presentation"><a href="<?php echo $weburl; ?>withdraw">Withdraw</a></li>
					<li role="presentation"><a href="<?php echo $weburl; ?>affiliate">Affiliate</a></li>
					<li role="presentation"><a href="<?php echo $weburl; ?>faucet">Faucet</a></li>
				</ul>
				<ul class="nav nav-pills pull-right">
					<li role="presentation"><a href="<?php echo $weburl; ?>transactions">Transactions</a></li>
					<li role="presentation"><a href="<?php echo $weburl; ?>logout">Logout</a></li>
				</ul>
			</nav>
			</br>
			<h1><?php echo $website; ?></h1>
		</div>