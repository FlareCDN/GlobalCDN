<?php
session_start();
include 'config.php';
define("SECURED", "OK");

if(isset($_GET['ref'])){
	$_SESSION['ref'] = $_GET['ref'];
}


if($shortlink_entry == "true"){
	if(!isset($_SESSION['key'])){
		$_SESSION['key'] = rand("11111", "9999999");
	}
	if(isset($_GET['key'])){
		$magkey = $_GET['key'];
		$sesskey = $_SESSION['key'];
		
		if($magkey == $sesskey){
			$_SESSION['vD'] = "VALID";
		}
	}
	if(!isset($_SESSION['vD'])){
		if(!isset($_SESSION['stone'])){
			$result = file_get_contents("http://api.adf.ly/api.php?key=$adfly_key&uid=$adfly_id&advert_type=int&domain=adf.ly&url=$weburl?key=".$_SESSION['key']);
			$_SESSION['stone'] = $result;
		}
		header("Location: ".$_SESSION['stone']);
		die();
	}
}

if(isset($_POST['wallid'])){
	$wallet = $_POST['wallid'];
	$ref = $_POST['ref'];
	
	if($wallet == ""){
		header("Location: ?wallet_empty");
		die();
	}
	if($ref == ""){
		$ref = 'none';
	}
	if($wallet == $ref){
		header("Location: ?nice_try");
		die();
	}
	$time = time();
	$sql = "SELECT * FROM wallets WHERE wallet = '$wallet'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$_SESSION['wallet'] = $row['wallet'];
			$_SESSION['balance'] = $row['balance'];
			header("Location: earn.php");
			die("Success!");
		}
	} else {
		if($ref == "none"){
			
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,"https://faucethub.io/api/v1/checkaddress");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,
					"api_key=$apikey&address=$wallet&currency=$shortcurrency");
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
	
			$check = json_decode($server_output,true);
			if($check['status'] == "200"){
				$sql = "INSERT INTO wallets (id, wallet, ref, balance, refbal, timestamp, lastclaim)VALUES ('', '$wallet', '$ref', '0', '0', '$time', '10000')";

				if ($conn->query($sql) === TRUE) {
					$_SESSION['wallet'] = $wallet;
					$_SESSION['balance'] = '0';
					header("Location: $weburl/earn");
					die("Success!");
				}
			} else {
				header("Location: $weburl?wallet_not_found");
				die("Your Wallet is not Linked to FaucetHub.IO");
			} 
			
		} else {
			$sql = "SELECT wallet FROM wallets WHERE wallet = '$ref'";
			$result = $conn->query($sql);

			if ($result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					$sql = "INSERT INTO wallets(id, wallet, ref, balance, refbal, timestamp, lastclaim)VALUES('', '$wallet', '$ref', '0', '0', '$time', '10000')";
					if ($conn->query($sql) === TRUE) {
						$_SESSION['wallet'] = $wallet;
						$_SESSION['balance'] = '0';
						header("Location: ".$weburl."earn");
						die("Success!");
					} else {
						header("Location: $weburl?e1");
						die("ERROR!");
					}
				}
			} else {
				$sql = "INSERT INTO wallets(id, wallet, ref, balance, refbal, timestamp, lastclaim, lastclaim)VALUES('', '$wallet', 'none', '0', '0', '$time' '10000')";
				if ($conn->query($sql) === TRUE) {
					$_SESSION['wallet'] = $wallet;
					$_SESSION['balance'] = '0';
					header("Location: ".$weburl."earn");
					die("Success!");
				} else {
					header("Location: $weburl?e2");
					die("ERROR!");
				}
			}
		}
	}
}



?>
<?php include 'includes/head.php'; ?>
<body>
	<div class="container">
		<div class="header clearfix">
			<nav>
				<ul class="nav nav-pills pull-right">
					<li role="presentation" class="active"><a href"<?php echo $weburl; ?>/index">Home</a></li>
				</ul>
			</nav>
			<h1><?php echo $website; ?></h1>
		</div>
		<div class="jumbotron">
			<h1>How it works ?</h1>
			<p>Earn <?php echo $currency; ?> by visiting Websites. For 10 seconds</p>
			<h3><b>Insert your FaucetHub.IO <?php echo $currency; ?> Wallet below :</b></h3>
			<form action="" method="POST">
				<input type="text" name="wallid" autocomplete="on" style="width:506px;height:38px;">
				<input type="hidden" name="ref" value="<?php echo $_SESSION['ref']; ?>">
				<br>
				<br>
				<p><input type="submit" class="btn btn-lg btn-success" name="login" value="Start Now"></p>
			</form>
		</div>
		<center><h2><b>Sponsors</b></h2></center>
		<br>
		<center>
			<?php if($ptcwall_status == "true"){ ?><img src="img/ptcw.jpg" width="30%"><?php } ?>
			<?php if($personaly_status == "true"){ ?><img src="img/personaly.png" width="30%"><?php } ?>
			<?php if($adscendmedia_status == "true"){ ?><img src="img/adscendmedia.webp" width="30%"><?php } ?>
			<?php if($superrewards_status == "true"){ ?><img src="img/superrewards.png" width="30%"><?php } ?>
		</center>
		</br>
		<p>
		</p>
	</div>
    <br>
<footer class="footer">
	<center> &copy; <?php date("Y"); ?> <?php echo $website; ?> </center>
</footer>
</div>
<!-----
/*
$$$$$$$$\ $$\                                $$$$$$\   $$$$$$\      $$\   $$\ $$$$$$$$\ $$$$$$$$\ 
$$  _____|$$ |                              $$  __$$\ $$  __$$\     $$$\  $$ |$$  _____|\__$$  __|
$$ |      $$ | $$$$$$\   $$$$$$\   $$$$$$\  $$ /  \__|$$ /  $$ |    $$$$\ $$ |$$ |         $$ |   
$$$$$\    $$ | \____$$\ $$  __$$\ $$  __$$\ $$ |      $$ |  $$ |    $$ $$\$$ |$$$$$\       $$ |   
$$  __|   $$ | $$$$$$$ |$$ |  \__|$$$$$$$$ |$$ |      $$ |  $$ |    $$ \$$$$ |$$  __|      $$ |   
$$ |      $$ |$$  __$$ |$$ |      $$   ____|$$ |  $$\ $$ |  $$ |    $$ |\$$$ |$$ |         $$ |   
$$ |      $$ |\$$$$$$$ |$$ |      \$$$$$$$\ \$$$$$$  | $$$$$$  |$$\ $$ | \$$ |$$$$$$$$\    $$ |   
\__|      \__| \_______|\__|       \_______| \______/  \______/ \__|\__|  \__|\________|   \__| 

*/
	<div id="fake-container-for-00Webhost-Square7-etc"></div>
</body>
</html>
