<?php

############################ BASIC SETTINGS START ##################################

//Website Settings
$website = 'CryptoHydra'; // ILOVEMONEY
$weburl = 'http://cryptohydra.net/'; // https://myepicurl.com/   ATTENTION PLEASE INCLUDE THE "/" AT THE END!
$currency = 'Bitcoin'; // Dogecoin, Blackckoin, Bitcoin, Peercoin, Litecoin, Dash, Primecoin
$smallcurrency = 'Satoshi'; // Satoshi, Blacktoshi, Litoshi, .....
$refshare = '100'; //Percentage = 20 for 20%


//Keep Me Updating this Script. | Its send 1 Satoshi (BTC) with every payout to me.
//I dont hardcoded this fee in WallScript. Its located at the withdraw.php file.
//If you set it to "false" it dont send 1 Satoshi to me. || Set it to "true" to allow me getting a Devfee.
$devfee = "true";

//Multiplicator Settings
$multiplicator = "false";
$multiplicator_amount = "2";

//FaucetHub.io Settings
$shortcurrency = 'BTC'; //Only Uppercase (BTC, LTC, DOGE, ....)
$apikey = ''; // https://faucethub.io/manager/faucets

//Min Withdraw
$mindraw = "15000";

############################ BASIC SETTINGS END ##################################

############################ FAUCET SETTINGS START ##################################


//Faucet
$reward = rand("2", "5"); //Reward for Using the Faucet.
$timewaiting = "300"; //Waiting time for the Faucet.

//Recaptcha Settings for Faucet!

$recaptcha_public = "6Ld99kYUAAAAA";
$recaptcha_private = "6Ld99kYUAAAAAFuQ";

############################ FAUCET SETTINGS END ##################################

############################ SHORTURL ENTRY START ##################################

//Protected Entry via ShortLink
$shortlink_entry = "false";

$adfly_key = "fd608e6d0121eee2";
$adfly_id = "1842";

############################ SHORTURL ENTRY END ##################################

############################ SHORTURL VERIFY START ##################################

//Services:
// 0 = Disabled
// 1 = http://1ink.cc/index.php
$shorturl = "false"; // true or false
$shorturl_service = "2"; // http://1ink.cc/index.php

//Service 1
$shorturl_service_1inc_id = "";
$shorturl_service_1inc_uname = "";

//Service 2
$shorturl_service_onlinebee_apikey = "579b66ca2939ab01ec4";

############################ SHORTURL VERIFY END ##################################

############################ OFFERWALL SECTION START ##################################


//Enable / Disable Offerwalls
$ptcwall_status = "false";
$personaly_status = "false";
$adscendmedia_status = "false";
$superrewards_status = "false";

//PTCWall API
$pubid = 'q844421304m7'; // Your Publisher ID
$postpass= 'ILkOL678jx9A'; //Your Postback Password
//PTCWall, you need to select "Points" instead of Cash type during the "Add Site Registration"
//Normal you need to set the rate to "10000" or "100000"

//Personaly API
$personaly_id = "dfba3e567bc4"; //The Offerwall Iframe ID.
$personaly_public = "511212ace";
$personaly_private = "1d59d56351922f8";

//Adscendmedia API
$adscendmedia_pub_id = "1051";
$adscendmedia_wall_id = "124";

//SuperRewards API
$superrewards_app_hash = "omihpx671";
$superrewards_postback_key = "43a1bc4";

############################ OFFERWALL SECTION END ##################################

############################ DATABASE SECTION START ##################################

//Database Settings
$dbhost = 'localhost';
$dbuser = '';
$dbpass = '';
$dbselect = '';

$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbselect);

############################ DATABASE SECTION END ##################################

//This script was made by FlareCO -> https://ophosting.net & https://flareco.net
//hYou are not allowed to resell this script!

/*
$$$$$$$$\ $$\                                $$$$$$\   $$$$$$\      $$\   $$\ $$$$$$$$\ $$$$$$$$\ 
$$  _____|$$ |                              $$  __$$\ $$  __$$\     $$$\  $$ |$$  _____|\__$$  __|
$$ |      $$ | $$$$$$\   $$$$$$\   $$$$$$\  $$ /  \__|$$ /  $$ |    $$$$\ $$ |$$ |         $$ |   
$$$$$\    $$ | \____$$\ $$  __$$\ $$  __$$\ $$ |      $$ |  $$ |    $$ $$\$$ |$$$$$\       $$ |   
$$  __|   $$ | $$$$$$$ |$$ |  \__|$$$$$$$$ |$$ |      $$ |  $$ |    $$ \$$$$ |$$  __|      $$ |   
$$ |      $$ |$$  __$$ |$$ |      $$   ____|$$ |  $$\ $$ |  $$ |    $$ |\$$$ |$$ |         $$ |   
$$ |      $$ |\$$$$$$$ |$$ |      \$$$$$$$\ \$$$$$$  | $$$$$$  |$$\ $$ | \$$ |$$$$$$$$\    $$ |   
\__|      \__| \_______|\__|       \_______| \______/  \______/ \__|\__|  \__|\________|   \__| 

*/
?>